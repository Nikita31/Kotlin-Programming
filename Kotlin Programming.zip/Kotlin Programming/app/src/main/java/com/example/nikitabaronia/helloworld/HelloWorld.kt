package com.example.nikitabaronia.helloworld


/*There is no need to have a class to run main function in Kotlin, it internally
//creates a Kt file with file name at run time which is handled by JVM, since kotlin does not
//support static functions*/
fun main(args : Array<String>){
    println("Hello World, how are you doing?")
    println("This is my first App")
}